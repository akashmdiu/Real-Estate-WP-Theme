<?php global $garo_estate; ?>
<div class="header-connect">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-sm-8  col-xs-12">
                <div class="header-half header-call">
                    <p>
                        <?php 
                            if(is_array($garo_estate['top-left'])){
                                foreach($garo_estate['top-left'] as $single_info){
                                    echo '<span><i class="pe-7s-'.$single_info['title'].'"></i> '.$single_info['url'].'</span>';
                                }
                            }
                        ?>
                    </p>
                </div>
            </div>
            <div class="col-md-2 col-md-offset-5  col-sm-3 col-sm-offset-1  col-xs-12">
                <div class="header-half header-social">
                    <ul class="list-inline">
                    <?php 
                            if(is_array($garo_estate['top-right'])){
                                foreach($garo_estate['top-right'] as $single_link){
                                    echo '<li><a href="'.$single_link['url'].'"><i class="fa fa-'.$single_link['title'].'"></i></a></li>';
                                }
                            }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>   