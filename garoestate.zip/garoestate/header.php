<?php global $garo_estate; ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="author" content="Kimarotec">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        
        <?php wp_head(); ?>
    </head>
    <body>

        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div>
        <!-- Body content -->
        <?php 
            if($garo_estate['top_bar']){
                echo get_template_part('template-part/top-bar');
            }
        ?>
             
        <!--End top header -->

        <nav class="navbar navbar-default ">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url(site_url()); ?>"><img src="<?php echo $garo_estate['logo']['url'];?>" alt=""></a>
                </div>
                
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse yamm" id="navigation">
                    <div class="button navbar-right">
                        <?php
                            if(is_user_logged_in()){?>
                               <a href="<?php echo esc_url(site_url()); ?>/wp-admin/profile.php"> <?php echo get_avatar(get_the_author_meta('ID'), 45);?></a>
                            <?php }
                            else{?>
                                <a href="<?php echo esc_url(site_url()); ?>/wp-login.php"> <button class="navbar-btn nav-button wow bounceInRight login">Login</button></a>
                                <a href="<?php echo esc_url(site_url()); ?>/wp-login.php?action=register"> <button class="navbar-btn nav-button">Signup</button></a>
                           <?php }
                        ?>
                       
                        
                    </div>
                    
                    <?php
                        wp_nav_menu(array(
                            'theme_location' => 'primary_menu',
                            'menu_class' => 'main-nav nav navbar-nav navbar-right',
                            'link_after' => '<b class="caret"></b>',
                        ));
                    ?>                 
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
        <!-- End of nav bar -->