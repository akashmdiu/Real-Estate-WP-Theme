<?php get_header(); 
/*
Template Name: Front Page
*/
?>

        <div class="slider-area">
            <div class="slider">
                <div id="bg-slider" class="owl-carousel owl-theme">
                    <?php
                        $slider_image = $garo_estate['slider_image'];
                        $array_image = explode(',', $slider_image);
                        if(is_array($array_image)){
                            foreach($array_image as $image){
                                $get_image_src =  wp_get_attachment_image_src($image, 'full');
                                echo '<div class="item"><img src="'.$get_image_src[0].'" alt="GTA V"></div>';
                            }
                        }
                    ?>    
                </div>
            </div>
            <div class="slider-content">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 col-sm-12">
                    
                        <h2><?php echo $garo_estate['banner_title']; ?></h2>
                        <p><?php echo $garo_estate['banner_subtitle']; ?></p>
                        <div class="search-form wow pulse" data-wow-delay="0.8s">
                            
                            <?php
                                $page_search = new WP_Advanced_Search('myform'); 
                                $page_search->the_form();
                           // echo do_shortcode('[wd_asp id=1]');
                            ?>
                            <form action="" class=" form-inline">

                                <div style="display: none;" class="search-toggle">

                                
                                </div>                    

                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- property area -->
        <div class="content-area home-area-1 recent-property" style="background-color: #FCFCFC; padding-bottom: 55px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12 text-center page-title">
                        <!-- /.feature title -->
                        <h2><?php echo $garo_estate['property_title']; ?></h2>
                        <p><?php echo $garo_estate['property_subtitle']; ?></p>
                    </div>
                </div>

                <div class="row">
                    <div class="proerty-th">
                        <?php
                            $sq = 10.7639;
                            $query = new WP_Query(array(
                                'post_type' => 'properties',
                                'posts_per_page' => 7,
                                'order' => 'DSC'
                            ));
                            if($query -> have_posts()){
                                while($query -> have_posts()) : $query -> the_post();
                                    $area = get_post_meta(get_the_id(), 'area', true); 
                                    $price = get_post_meta(get_the_id(), 'sell_price', true);
                                    $property_thumbnail = get_post_meta(get_the_id(), 'property_thumbnail', true);
                                    $currency = get_post_meta(get_the_id(), 'currency', true);
                                    
                                ?>
                                    <div class="col-sm-6 col-md-3 p0">
                                        <div class="box-two proerty-item">
                                            <div class="item-thumb">
                                                <a href="<?php echo the_permalink(); ?>" ><img src="<?php echo $property_thumbnail; ?>" alt=""></a>
                                            </div>
                                            <div class="item-entry overflow">
                                                <h5><a href="<?php echo the_permalink(); ?>" ><?php the_title(); ?> </a></h5>
                                                <div class="dot-hr"></div>
                                                <span class="pull-left"><b>Area :</b> <?php echo intval($area/$sq); ?> m </span>
                                                <span class="proerty-price pull-right"> 
                                                    <?php
                                                        if($currency == '$'){
                                                            echo "$$currency $price";
                                                        }
                                                        else if($currency == '€'){
                                                            echo "$".intval($price*1.13);
                                                        }
                                                        else if($currency == '৳'){
                                                            echo "$".intval($price/83.79);
                                                        }
                                                    ?>
                                                </span>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    
                                <?php endwhile;?>
                                <div class="col-sm-6 col-md-3 p0">
                                    <div class="box-tree more-proerty text-center">
                                        <div class="item-tree-icon">
                                            <i class="fa fa-th"></i>
                                        </div>
                                        <div class="more-entry overflow">
                                            <h5><a href="<?php echo esc_url(site_url()); ?>/properties" >CAN'T DECIDE ? </a></h5>
                                            <h5 class="tree-sub-ttl">Show all properties</h5>
                                            <a href="<?php echo esc_url(site_url()); ?>/properties"><button class="btn btn-primary more-black" value="All properties">All properties</button></a>
                                        </div>
                                    </div>
                                </div>
                           <?php }
                        ?>
                        


                        

                    </div>
                </div>
            </div>
        </div>

        <!--Welcome area -->
        <div class="Welcome-area" style=" background-image: url(<?php echo $garo_estate['wecome_bg']['url']; ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 Welcome-entry  col-sm-12">
                        <div class="col-md-5 col-md-offset-2 col-sm-6 col-xs-12">
                            <div class="welcome_text wow fadeInLeft" data-wow-delay="0.3s" data-wow-offset="100">
                                <div class="row">
                                    <div class="col-md-10 col-md-offset-1 col-sm-12 text-center page-title">
                                        <!-- /.feature title -->
                                        <h2>GARO ESTATE </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-6 col-xs-12">
                            <div  class="welcome_services wow fadeInRight" data-wow-delay="0.3s" data-wow-offset="100">
                                <div class="row">
                                    <?php
                                        $x = 0;
                                        if(is_array($garo_estate['welcomm_support'])){
                                            foreach($garo_estate['welcomm_support'] as $sinle_support){
                                                    $x++;
                                                ?>
                                                <div class="col-xs-6 m-padding">
                                                    <div class="welcome-estate">
                                                        <div class="welcome-icon">
                                                            <i class="pe-7s-<?php echo $sinle_support['title']; ?> pe-4x"></i>
                                                        </div>
                                                        <h3><?php echo $sinle_support['url']; ?></h3>
                                                    </div>
                                                </div>
                                            <?php 
                                                if($x == 2){?>
                                                    <div class="col-xs-12 text-center">
                                                        <i class="welcome-circle"></i>
                                                    </div>
                                                <?php }
                                            }
                                        }
                                    ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--TESTIMONIALS -->
        <div class="testimonial-area recent-property" style="background-color: #FCFCFC; padding-bottom: 15px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12 text-center page-title">
                        <!-- /.feature title -->
                        <h2><?php echo $garo_estate['review_title']; ?></h2> 
                    </div>
                </div>

                <div class="row">
                    <div class="row testimonial">
                        <div class="col-md-12">
                            <div id="testimonial-slider">
                                <?php
                                    $query = new WP_Query(array(
                                        'post_type' => 'client_rview',
                                        'posts_per_page' => -1,
                                        'order' => 'ASC'
                                    ));
                                    if($query -> have_posts()){
                                        while($query -> have_posts()) : $query -> the_post();
                                            $position = get_post_meta(get_the_id(), 'post_position', true);
                                        ?>
                                             <div class="item">
                                                <div class="client-text">                                
                                                    <p><?php the_content(); ?></p>
                                                    <h4><strong><?php the_title(); ?>, </strong><i><?php echo $position; ?></i></h4>
                                                </div>
                                                <div class="client-face wow fadeInRight" data-wow-delay=".9s"> 
                                                    <?php the_post_thumbnail(); ?>
                                                </div>
                                            </div>
                                        <?php endwhile;
                                    }else{
                                        echo '<p>No review available.please<a href="'.esc_url(site_url()).'/wp-admin/post-new.php?post_type=client_review"> Add a review</a></p>';
                                    }
                                ?>
                               
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- boy-sale area -->
        <div class="boy-sale-area">
            <div class="container">
                <div class="row">

                    <div class="col-md-6 col-sm-10 col-sm-offset-1 col-md-offset-0 col-xs-12">
                        <div class="asks-first">
                            <div class="asks-first-circle">
                                <span class="fa fa-search"></span>
                            </div>
                            <div class="asks-first-info">
                                <h2><?php echo $garo_estate['check_title']; ?></h2>
                                <p> <?php echo $garo_estate['check_desc']; ?></p>                                        
                            </div>
                            <a href="<?php echo esc_url(site_url()); ?>/properties">
                            <div class="asks-first-arrow">
                               <span class="fa fa-angle-right"></span>
                            </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-10 col-sm-offset-1 col-xs-12 col-md-offset-0">
                        <div  class="asks-first">
                            <div class="asks-first-circle">
                                <span class="fa fa-usd"></span>
                            </div>
                            <div class="asks-first-info">
                                <h2><?php echo $garo_estate['sell_title']?></h2>
                                <p><?php echo $garo_estate['sell_desc']; ?></p>
                            </div>
                            <a href="<?php if(is_user_logged_in()){ echo esc_url(site_url()).'/wp-admin/post-new.php?post_type=properties'; }else{echo esc_url(site_url()).'/wp-login.php?action=register'; }?>">
                            <div class="asks-first-arrow">
                                <span class="fa fa-angle-right"></span>
                            </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <p  class="asks-call">QUESTIONS? CALL US  : <span class="strong"> <?php echo $garo_estate['contact_number']; ?></span></p>
                    </div>
                </div>
            </div>
        </div>
  
    <?php get_footer(); ?>