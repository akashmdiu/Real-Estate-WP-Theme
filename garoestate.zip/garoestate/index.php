<?php get_header();
/*
Template Name: Full Width Blog Page
*/
?>

        <div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title"><?php wp_title(); ?></h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header -->

        <div class="content-area blog-page padding-top-40" style="background-color: #FCFCFC; padding-bottom: 55px;">
            <div class="container">   
                <div class="row">
                    <div class="blog-lst col-md-12 pl0">
                        <?php 
                            if(have_posts()){
                                while(have_posts()) : the_post(); ?>
                                    <section class="post">
                                        <div class="text-center padding-b-50">
                                            <h2 class="wow fadeInLeft animated"><?php the_title(); ?></h2>
                                            <div class="title-line wow fadeInRight animated"></div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-6">
                                                <p class="author-category">
                                                    By <?php the_author_posts_link(); ?>
                                                    in <?php the_category(' '); ?>
                                                </p>
                                            </div>
                                            <div class="col-sm-6 right" >
                                                <p class="date-comments">
                                                    <span><i class="fa fa-calendar-o"></i> <?php the_time('d M, Y'); ?></span> | 
                                                    <span><i class="fa fa-comment-o"></i> <?php comments_number('0 Comment', '1 Comment', '% Comments'); ?></span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="image wow fadeInLeft animated">
                                            <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
                                            </a>
                                        </div>
                                        <p class="intro"><?php echo cExcerpt(50); ?></p>
                                        <p class="read-more">
                                            <a href="<?php the_permalink(); ?>" class="btn btn-default btn-border">Continue reading</a>
                                        </p>
                                    </section>   
                                <?php endwhile;
                            }
                        ?>
                        
                        
                        <div class="post-pagination">
                        <?php 
                            the_posts_pagination(array(
                                'prev_text' => '«',
                                'next_text' => '»',
                                'mid_size'  => 5,
                                'screen_reader_text' => ' '
                            ));
                        ?>
                    </div>

                    </div>  
                </div>

            </div>
        </div>

     <?php get_footer(); ?>