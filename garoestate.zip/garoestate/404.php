<?php get_header(); ?>
      
        <div class="content-area error-page" style="background-color: #FCFCFC; padding-bottom: 55px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 col-md-offset-1 col-sm-12 text-center page-title">
                        <h2 class="error-title">404</h2>
                        <p>Sorry, the page you requested may have been moved or deleted</p>
                        <a href="<?php esc_url(site_url()); ?>" class="btn btn-default"><i style="margin-right:2px;" class="fa fa-home"></i>Home</a>                        
                    </div>
                </div> 
            </div>
        </div> 

   <?php get_footer(); ?>