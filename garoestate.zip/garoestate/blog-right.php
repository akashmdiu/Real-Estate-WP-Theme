<?php get_header(); 
/*
Template Name: Blog with Right Sidebar
*/
?>

        <div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title"><?php wp_title(); ?></h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header -->

        <div class="content-area blog-page padding-top-40" style="background-color: #FCFCFC; padding-bottom: 55px;">
            <div class="container">   
                <div class="row">
                    <div class="blog-lst col-md-9">
                        <?php 
                            $my_current_page = get_query_var('paged');
                            $query = new WP_Query(array(
                                'post_type' => 'post',
                                'paged' => $my_current_page,
                            ));
                            if($query->have_posts()){
                                while($query->have_posts()) : $query->the_post(); ?>
                                    <section class="post">
                                        <div class="text-center padding-b-50">
                                            <h2 class="wow fadeInLeft animated"><?php the_title(); ?></h2>
                                            <div class="title-line wow fadeInRight animated"></div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-6">
                                                <p class="author-category">
                                                    By <?php the_author_posts_link(); ?>
                                                    in <?php the_category(' '); ?>
                                                </p>
                                            </div>
                                            <div class="col-sm-6 right" >
                                                <p class="date-comments">
                                                    <span><i class="fa fa-calendar-o"></i> <?php the_time('d M, Y'); ?></span> | 
                                                    <span><i class="fa fa-comment-o"></i> <?php comments_number('0 Comment', '1 Comment', '% Comments'); ?></span>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="image wow fadeInLeft animated">
                                            <a href="<?php the_permalink(); ?>">
                                                <?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
                                            </a>
                                        </div>
                                        <p class="intro"><?php echo cExcerpt(50); ?></p>
                                        <p class="read-more">
                                            <a href="<?php the_permalink(); ?>" class="btn btn-default btn-border">Continue reading</a>
                                        </p>
                                    </section>   
                                <?php endwhile;
                                    echo '<div class="post-pagination">';
                                        echo paginate_links(array(
                                                'total' => $query->max_num_pages,
                                                'next_text' => 'Next',
                                                'prev_text' => 'Previous',
                                                'mid_size' => '2'
                                        ));
                                    echo '</div>';
                            }else{
                                echo '<a href="'.esc_url(site_url()).'/wp-admin/post-new.php">Create a Post</a>';
                            }
                        ?>

                    </div> 

                    <div class="blog-asside-right col-md-3">
                        <?php 
                            if(!dynamic_sidebar('sidebar')){?>
                                <a  href="<?php echo esc_url(site_url()); ?>/wp-admin/widgets.php"><h4 class="text-center">Add Sidebar</h4></a>
                           <?php }
                        ?>
                    </div>
                </div>

            </div>
        </div>

        
      <?php get_footer(); ?>