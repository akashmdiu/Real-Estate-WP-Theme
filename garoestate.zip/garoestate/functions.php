<?php
    function after_setup_theme(){
        add_theme_support('post-thumbnails');
        add_theme_support('title-tag');
    }
    add_action('after_setup_theme', 'after_setup_theme');

    include_once('inc/cssJss.php');
    include_once('inc/menu.php');
    require_once('inc/redux-framework/redux-framework.php');
    require_once('inc/theme-options.php');
    require_once('inc/cmb2-custom-fields.php');
    include_once('inc/cmb2-custom-fields.php');
    include_once('inc/register-post.php');
    include_once('inc/searchform.php');
    require_once('inc/wp-advanced-search/wpas.php');
    include_once('inc/register_sidebar.php');
    include_once('inc/excerpt.php');
    require_once('inc/tgm-plugin/class-tgm-plugin-activation.php');
    require_once('inc/garoEstatePlugin.php')
    
?>