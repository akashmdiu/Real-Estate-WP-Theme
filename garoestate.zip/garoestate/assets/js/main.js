jQuery(window).load(function () { // makes sure the whole site is loaded
    jQuery('#status').fadeOut(); // will first fade out the loading animation
    jQuery('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
    jQuery('body').delay(350).css({'overflow': 'visible'});
})
jQuery(document).ready(function () {

    
    jQuery('input').iCheck({
        checkboxClass: 'icheckbox_square-yellow',
        radioClass: 'iradio_square-yellow',
        increaseArea: '20%' // optional
    });


    jQuery('.layout-grid').on('click', function () {
        jQuery('.layout-grid').addClass('active');
        jQuery('.layout-list').removeClass('active');

        jQuery('#list-type').removeClass('proerty-th-list');
        jQuery('#list-type').addClass('proerty-th');

    });

    jQuery('.layout-list').on('click', function () {
        jQuery('.layout-grid').removeClass('active');
        jQuery('.layout-list').addClass('active');

        jQuery('#list-type').addClass('proerty-th-list');
        jQuery('#list-type').removeClass('proerty-th');

    });

});
jQuery(document).ready(function () {
    jQuery("#bg-slider").owlCarousel({
        navigation: false, // Show next and prev buttons
        slideSpeed: 100,
        autoPlay: 5000,
        paginationSpeed: 100,
        singleItem: true,
        mouseDrag: false,
        transitionStyle: "fade"
                // "singleItem:true" is a shortcut for:
                // items : 1, 
                // itemsDesktop : false,
                // itemsDesktopSmall : false,
                // itemsTablet: false,
                // itemsMobile : false 
    });
    jQuery("#prop-smlr-slide_0").owlCarousel({
        navigation: false, // Show next and prev buttons
        slideSpeed: 100,
        pagination: true,
        paginationSpeed: 100,
        items: 3

    });
    jQuery("#testimonial-slider").owlCarousel({
        navigation: false, // Show next and prev buttons
        slideSpeed: 100,
        pagination: true,
        paginationSpeed: 100,
        items: 3
    });

    jQuery('#price-range').slider();
    jQuery('#property-geo').slider();
    jQuery('#min-baths').slider();
    jQuery('#min-bed').slider();

    var RGBChange = function () {
        jQuery('#RGB').css('background', '#FDC600')
    };

    // Advanced search toggle
    var $SearchToggle = jQuery('.search-form .search-toggle');
    $SearchToggle.hide();

    jQuery('.search-form .toggle-btn').on('click', function (e) {
        e.preventDefault();
        $SearchToggle.slideToggle(300);
    });

    setTimeout(function () {
        jQuery('#counter').text('0');
        jQuery('#counter1').text('0');
        jQuery('#counter2').text('0');
        jQuery('#counter3').text('0');
        setInterval(function () {
            var curval = parseInt(jQuery('#counter').text());
            var curval1 = parseInt(jQuery('#counter1').text().replace(' ', ''));
            var curval2 = parseInt(jQuery('#counter2').text());
            var curval3 = parseInt(jQuery('#counter3').text());
            if (curval <= 1007) {
                jQuery('#counter').text(curval + 1);
            }
            if (curval1 <= 1280) {
                jQuery('#counter1').text(sdf_FTS((curval1 + 20), 0, ' '));
            }
            if (curval2 <= 145) {
                jQuery('#counter2').text(curval2 + 1);
            }
            if (curval3 <= 1022) {
                jQuery('#counter3').text(curval3 + 1);
            }
        }, 2);
    }, 500);

    function sdf_FTS(_number, _decimal, _separator) {
        var decimal = (typeof (_decimal) != 'undefined') ? _decimal : 2;
        var separator = (typeof (_separator) != 'undefined') ? _separator : '';
        var r = parseFloat(_number)
        var exp10 = Math.pow(10, decimal);
        r = Math.round(r * exp10) / exp10;
        rr = Number(r).toFixed(decimal).toString().split('.');
        b = rr[0].replace(/(\d{1,3}(?=(\d{3})+(?:\.\d|\b)))/g, "\$1" + separator);
        r = (rr[1] ? b + '.' + rr[1] : b);

        return r;
    }

})
jQuery(document).ready(function () {

    jQuery('#image-gallery').lightSlider({
        gallery: true,
        item: 1,
        thumbItem: 9,
        slideMargin: 0,
        speed: 500,
        auto: true,
        loop: true,
        onSliderLoad: function () {
            jQuery('#image-gallery').removeClass('cS-hidden');
        }
    });
    jQuery('#flat-slider').slider({
        orientation: 'horizontal',
        range:       true,
        values:      [17,67]
      });
});
// Initializing WOW.JS

new WOW().init();