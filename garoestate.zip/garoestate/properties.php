<?php get_header();
/*
Template Name: Properties Page
*/
?>

        <div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title">List Layout With Sidebar</h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header -->

        <!-- property area -->
        <div class="properties-area recent-property" style="background-color: #FFF;">
            <div class="container">  
                <div class="row">
                     
                <div class="col-md-3 p0 padding-top-40">
                    <div class="blog-asside-right pr0">
                        <div class="panel panel-default sidebar-menu wow fadeInRight animated" >
                            <div class="panel-heading">
                                <h3 class="panel-title">Smart search</h3>
                            </div>
                            <div class="search">
                                <?php
                                    $my_search = new WP_Advanced_Search('anotherform');
                                    $my_search->the_form();
                                    
                                ?>
                               
                            </div>
                            
                        </div>

                        
                    </div>
                </div>

                <div class="col-md-9  pr0 padding-top-40 properties-page">
                    <div class="col-md-12 clear"> 

                        <div class="col-xs-12 layout-switcher">
                            <a class="layout-list" href="javascript:void(0);"> <i class="fa fa-th-list"></i>  </a>
                            <a class="layout-grid active" href="javascript:void(0);"> <i class="fa fa-th"></i> </a>                          
                        </div><!--/ .layout-switcher-->
                    </div>

                    <div class="col-md-12 clear"> 
                        <div id="list-type" class="proerty-th max-height">
                        <?php 
                            $sq = 10.7639;
                            $query = new WP_Query(array(
                                'post_type' => 'properties',
                                'posts_per_page' => 5,
                                'order' => 'ASC'
                            ));
                            if($query->have_posts()){
                                while($query -> have_posts()) : $query -> the_post();
                                    $area = get_post_meta(get_the_id(), 'area', true); 
                                    $price = get_post_meta(get_the_id(), 'sell_price', true);                             
                                    $garages = get_post_meta(get_the_id(), 'garages', true);
                                    $badrooms = get_post_meta(get_the_id(), 'badrooms', true);                      
                                    $bathrooms = get_post_meta(get_the_id(), 'bathrooms', true);                      
                                    $status = get_post_meta(get_the_id(), 'status', true);
                                    $water_front = get_post_meta(get_the_id(), 'water_front', true);
                                    $builtInDate = get_post_meta(get_the_id(), 'builtInDate', true);
                                    $parking_space = get_post_meta(get_the_id(), 'parking-space', true);
                                    $wFront = get_post_meta(get_the_id(), 'wFront', true);
                                    $view = get_post_meta(get_the_id(), 'view', true);
                                    $feature = get_post_meta(get_the_id(), 'feature', true);
                                    $property_photos = get_post_meta(get_the_id(), 'property_photos', true);
                                    $property_video = get_post_meta(get_the_id(), 'property_video', true);
                                    $property_location = get_post_meta(get_the_id(), 'property_location', true);
                                    $property_type = get_post_meta(get_the_id(), 'property_type', true);
                                    $property_thumbnail = get_post_meta(get_the_id(), 'property_thumbnail', true);
                                ?>
                                    <div class="col-sm-6 col-md-4 p0">
                                        <div class="box-two proerty-item">
                                            <div class="item-thumb">
                                                <a href="<?php the_permalink(); ?>" ><img src="<?php echo $property_thumbnail; ?>" alt=""></a>
                                                
                                            </div>
                                            <div class="item-entry overflow">
                                                <h5><a href="<?php the_permalink(); ?>"> <?php the_title(); ?> </a></h5>
                                                <div class="dot-hr"></div>
                                                <span class="pull-left"><b> Area :</b> <?php echo intval($area/$sq); ?>m </span>
                                                <span class="proerty-price pull-right"> $ <?php echo $price; ?></span>
                                                <p><?php echo cExcerpt(35);?></p>
                                                <div class="property-icon">
                                                <p class="location" style="display:inline-block">
                                                    <span id="marker" class="pe-7s-map-marker""></span><?php echo $property_location;?> | </p> 
                                                <p class="location" style="display:inline-block">
                                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/bed.png"> [<?php echo $badrooms; ?>] |
                                                    </p>
                                                    <p class="location" style="display:inline-block">
                                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/shawer.png"> [<?php echo $bathrooms; ?>]
                                                    </p>
                                                    
                                                   
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                               <?php endwhile;
                            }
                        ?>
                       
                                                           
                        </div>
                    </div>
                    
                    <div class="col-md-12"> 
                        <div class="pull-right">
                            <div class="pagination">
                                 <?php $my_search->pagination(); ?>
                            </div>
                        </div>                
                    </div>
                </div>  
                </div>              
            </div>
        </div>

      <?php echo get_footer(); ?>