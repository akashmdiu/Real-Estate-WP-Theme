<?php get_header(); ?>

        <div class="page-head"> 
            <div class="container">
                <div class="row">
                    <div class="page-head-content">
                        <h1 class="page-title">FAQ PAge</h1>               
                    </div>
                </div>
            </div>
        </div>
        <!-- End page header -->

        <div class="content-area blog-page padding-top-40" style="background-color: #FCFCFC; padding-bottom: 55px;">
            <div class="container">
                <div class="row">
                    <div class="blog-lst col-md-12 pl0">
                    <section id="id-100" class="post single">
                        <?php
                            if(have_posts()){
                                while(have_posts()) : the_post(); ?>
                                   
                                        <div class="post-header single">
                                            <div class="">
                                                <h2 class="wow fadeInLeft animated"><?php the_title(); ?></h2>
                                                <div class="title-line wow fadeInRight animated"></div>
                                            </div>
                                            <div class="row wow fadeInRight animated">
                                                <div class="col-sm-6">
                                                    <p class="author-category">
                                                        By <?php the_author_posts_link(); ?>
                                                        in <?php the_category(" "); ?>
                                                    </p>
                                                </div>
                                                <div class="col-sm-6 right" >
                                                    <p class="date-comments">
                                                        <span><i class="fa fa-calendar-o"></i> <?php the_time('d M, Y'); ?></span> | 
                                                        <span><i class="fa fa-comment-o"></i> <?php comments_number('0 Comment', '1 Comment', '% Comments'); ?></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="image wow fadeInRight animated"> 
                                                <?php the_post_thumbnail('large', array('class' => 'img-responsive'));?>
                                            </div>
                                        </div> 

                                        <div id="post-content" class="post-body single wow fadeInLeft animated">
                                            <p>
                                               <?php the_content(); ?>
                                            </p>

                                        </div>
                                       
                                <?php endwhile;
                            }
                        ?>
                            <div class="post-footer single wow fadeInBottum animated">
                                <ul class="pager">
                                <li class="previousn"> <?php previous_post_link(); ?></li>
                                    <li class="nextb"><?php next_post_link(); ?></li>
                                </ul> 
                            </div>    

                        </section> 

                        <section class="about-autor">

                        </section>

                        <section id="comments" class="comments wow fadeInRight animated"> 
                            <h4 class="text-uppercase wow fadeInLeft animated">3 comments</h4>


                            <div class="row comment">
                                <div class="col-sm-3 col-md-2 text-center-xs">
                                    <p>
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/client-face1.png" class="img-responsive img-circle" alt="">
                                    </p>
                                </div>
                                <div class="col-sm-9 col-md-10">
                                    <h5 class="text-uppercase">Julie Alma</h5>
                                    <p class="posted"><i class="fa fa-clock-o"></i> September 23, 2011 at 12:00 am</p>
                                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper.
                                        Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
                                    <p class="reply"><a href="#"><i class="fa fa-reply"></i> Reply</a>
                                    </p>
                                </div>
                            </div>
                            <!-- /.comment -->


                            <div class="row comment last">

                                <div class="col-sm-3 col-md-2 text-center-xs">
                                    <p>
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/client-face2.png" class="img-responsive img-circle" alt="">
                                    </p>
                                </div>

                                <div class="col-sm-9 col-md-10">
                                    <h5 class="text-uppercase">Louise Armero</h5>
                                    <p class="posted"><i class="fa fa-clock-o"></i> September 23, 2012 at 12:00 am</p>
                                    <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper.
                                        Aenean ultricies mi vitae est. Mauris placerat eleifend leo.</p>
                                    <p class="reply"><a href="#"><i class="fa fa-reply"></i> Reply</a>
                                    </p>
                                </div>

                            </div>
                            <!-- /.comment -->
                        </section>

                        <section id="comment-form" class="add-comments">
                            <h4 class="text-uppercase wow fadeInLeft animated">Leave comment</h4>
                            <form>
                                <div class="row wow fadeInLeft animated">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="name">Name <span class="required">*</span>
                                            </label>
                                            <input class="form-control" id="name" type="text">
                                        </div>
                                    </div>
                                </div>

                                <div class="row wow fadeInLeft animated">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="email">Email <span class="required">*</span>
                                            </label>
                                            <input class="form-control" id="email" type="text">
                                        </div>
                                    </div>
                                </div>

                                <div class="row wow fadeInLeft animated">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label for="comment">Comment <span class="required">*</span>
                                            </label>
                                            <textarea class="form-control" id="comment" rows="4"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="row wow fadeInLeft animated">
                                    <div class="col-sm-12 text-right">
                                        <button class="btn btn-primary"><i class="fa fa-comment-o"></i> Post comment</button>
                                    </div>
                                </div>
                            </form>
                        </section>
                    </div>                                 
                </div>

            </div>
        </div>

<?php get_footer(); ?>