<?php
    register_sidebar(array(
        'name' => 'Sidebar Widget',
        'id' => 'sidebar_widget',
        'before_title' => '<div class="widget_title"><h3>',
        'after_title' => '</h3></div>',
        'before_widget' => '<div class="right-sidebar mb clearfix">',
        'after_widget' => '</div>'
    ));
    register_sidebar(array(
        'name' => 'blog page',
        'id' => 'blog_page',
    ));
    register_sidebar(array(
        'name' => 'Footer One',
        'id'   =>  'footer_one',
        'before_title' => '<div class="footer-title">
        <h3>',
        'after_title' => '</h3></div>',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Footer Two',
        'id'   =>  'footer_two',
        'before_title' => '<div class="footer-title">
        <h3>',
        'after_title' => '</h3></div>',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Footer Three',
        'id'   =>  'footer_three',
        'before_title' => '<div class="footer-title">
        <h3>',
        'after_title' => '</h3></div>',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Footer Four',
        'id'   =>  'footer_four',
        'before_title' => '<div class="footer-title">
        <h3>',
        'after_title' => '</h3></div>',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>'
    ));