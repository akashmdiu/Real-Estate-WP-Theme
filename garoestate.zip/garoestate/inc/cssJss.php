<?php
    function callCssJs(){
        //call google fonts
        wp_enqueue_style('google-font', '//fonts.googleapis.com/css?family=Open+Sans:400,300,700,800');

        //CSS File
        wp_enqueue_style('normalize', get_template_directory_uri().'/assets/css/normalize.css', null, 'v1.0', 'all');
        wp_enqueue_style('font-awesome', get_template_directory_uri().'/assets/css/font-awesome.min.css', null, 'v1.0', 'all');
        wp_enqueue_style('fontello', get_template_directory_uri().'/assets/css/fontello.css', null, 'v1.0', 'all');
        wp_enqueue_style('pe-icon', get_template_directory_uri().'/assets/fonts/icon-7-stroke/css/pe-icon-7-stroke.css', null, 'v1.0', 'all');
        wp_enqueue_style('helper', get_template_directory_uri().'/assets/fonts/icon-7-stroke/css/helper.css', null, 'v1.0', 'all');
        wp_enqueue_style('animate', get_template_directory_uri().'/assets/css/animate.css', null, 'v1.0', 'all');
        wp_enqueue_style('bootrap-select', get_template_directory_uri().'/assets/css/bootstrap-select.min.css', null, 'v1.0', 'all');
        wp_enqueue_style('bootstrap', get_template_directory_uri().'/bootstrap/css/bootstrap.min.css', null, 'v1.0', 'all');
        wp_enqueue_style('icheck', get_template_directory_uri().'/assets/css/icheck.min_all.css', null, 'v1.0', 'all');
        wp_enqueue_style('price-range', get_template_directory_uri().'/assets/css/price-range.css', null, 'v1.0', 'all');
        wp_enqueue_style('owl-carousel', get_template_directory_uri().'/assets/css/owl.carousel.css', null, 'v1.0', 'all');
        wp_enqueue_style('owl-theme', get_template_directory_uri().'/assets/css/owl.theme.css', null, 'v1.0', 'all');
        wp_enqueue_style('transitions', get_template_directory_uri().'/assets/css/owl.transitions.css', null, 'v1.0', 'all');
        wp_enqueue_style('main-css', get_template_directory_uri().'/assets/css/style.css', null, 'v1.0', 'all');
        wp_enqueue_style('responsive', get_template_directory_uri().'/assets/css/responsive.css', null, 'v1.0', 'all');
        
        wp_enqueue_style('lightslider', get_template_directory_uri().'/assets/css/lightslider.min.css', null, 'v1.0', 'all');
        wp_enqueue_style('style-css', get_stylesheet_uri());
        
        //JS File
        wp_enqueue_script('jquery');
        wp_enqueue_script('modernizer', get_template_directory_uri().'/assets/js/modernizr-2.6.2.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('bootstrap-select', get_template_directory_uri().'/assets/js/bootstrap-select.min.js', 'jquery', 'v1.0', true);

        wp_enqueue_script('bootstrap', get_template_directory_uri().'/bootstrap/js/bootstrap.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('bootstrap-dropdown', get_template_directory_uri().'/assets/js/bootstrap-hover-dropdown.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('easypiechart', get_template_directory_uri().'/assets/js/easypiechart.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('easypiechart', get_template_directory_uri().'/assets/js/jquery.easypiechart.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('owl-carousel', get_template_directory_uri().'/assets/js/owl.carousel.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('lightslider', get_template_directory_uri().'/assets/js/lightslider.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('wow', get_template_directory_uri().'/assets/js/wow.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('icheck', get_template_directory_uri().'/assets/js/icheck.min.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('price', get_template_directory_uri().'/assets/js/price-range.js', 'jquery', 'v1.0', true);
        wp_enqueue_script('main', get_template_directory_uri().'/assets/js/main.js', 'jquery', 'v1.0', true);
        



    }
    add_action('wp_enqueue_scripts', 'callCssJs');
?>