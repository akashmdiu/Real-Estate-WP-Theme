<?php
    function navMenus(){
       register_nav_menus(array(
            'primary_menu' => 'Primary Menu',
            'footer_menu' => 'Footer Menu',
            'quick_links_menu' => 'Quick Links for Footer Widget'
       ));
    }   
    add_action('init', 'navMenus');
?>