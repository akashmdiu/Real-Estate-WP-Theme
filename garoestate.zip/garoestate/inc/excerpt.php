<?php
    function cExcerpt($limits = 20){
        $limits = $limits + 1;
        $content = strip_tags(get_the_content());
        $make_index = explode(' ', $content, $limits);
        if(count($make_index) <= $limits){
            array_pop($make_index);
        }
        $makeString = implode(' ', $make_index);
        return $makeString;

    }
?>