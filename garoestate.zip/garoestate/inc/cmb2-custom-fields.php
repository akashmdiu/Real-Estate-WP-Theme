<?php

/**
 * Get the bootstrap!
 * (Update path to use cmb2 or CMB2, depending on the name of the folder.
 * Case-sensitive is important on some systems.)
 */
require_once __DIR__ . '/CMB2/init.php';
$page = get_post_meta(get_the_id(), 'page_id', true);
function custom_fields(){

	$property_metabox = new_cmb2_box( array(
		'id'            => 'property_metabox',
		'title'         => __( 'Property Metabox', 'timermaster' ),
		'object_types'  => 'properties', // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, 
	) );
	$property_metabox->add_field( array(
		'name'             => 'Property Thumbnail',
		'id'               => 'property_thumbnail',
		'type'             => 'file',
		'text'			   => array(
			'add_upload_file_text' => 'Upload Thumbnail'
		),
		'description'      => 'Upload your property thumbnail',
		'options' => array(
			'url' => true
		)
	) );
	$property_metabox->add_field( array(
		'name'             => 'Property Photos',
		'id'               => 'property_photos',
		'type'             => 'file_list',
		'text'			   => array(
			'add_upload_files_text' => 'Upload photos'
		),
		'description'      => 'Upload multiple property Photos',
	) );
	
	$property_metabox->add_field( array(
		'name'             => 'Area',
		'id'               => 'area',
		'type'             => 'text_small',
		'description'      => 'Input your property area',
		'before_field'     => 'Sq Ft '
	) );
	
	$property_metabox->add_field( array(
		'name'             => 'Property Type',
		'id'               => 'property_type',
		'type'             => 'select',
		'options' => array(
			'flat'	=> 'Flats',
			'apartment' => 'Apartments',
			'rent' => 'Rents'
		),
		'default' => 'flat',
		'description'      => 'Select your property type',
	) );
	$property_metabox->add_field( array(
		'name'             => 'Property Location',
		'id'               => 'property_location',
		'type'             => 'select',
		'options' 		   => array(
			'dhaka'  => 'Dhaka',
			'barisal' => 'Barisal',
			'chittagong'  => 'Chittagong',
			'khulna' => 'Khulna',
			'sylhet'  => 'Sylhet',
			'mymensingh	' => 'Mymensingh',
			'rajshahi'  => 'Rajshahi',
			'rangpur' => 'Rangpur',
			'comilla'  => 'Comilla',
			'narayanganj' => 'Narayanganj',
			'gazipur'  => 'Gazipur',
		),
		'description'      => 'Input your property location city',
		'default'     => 'Dhaka'
	) );
	$property_metabox->add_field( array(
		'name'             => 'Sell Price',
		'id'               => 'sell_price',
		'type'             => 'text',
		'description'      => 'Input your property sell price',
		'before' 			=> '$ '
	) );
	$property_metabox->add_field( array(
		'name'             => 'Status For',
		'id'               => 'status',
		'type'             => 'radio',
		'options'          => array(
			'Sell' => __( 'Sell', 'garo-estate' ),
			'Buy'   => __( 'Buy', 'garo-estate' ),
		),
		'description'      => 'What you want?'
	) );
	$property_metabox->add_field( array(
		'name'             => 'Badrooms',
		'id'               => 'badrooms',
		'type'             => 'text_small',
		'description'      => 'How many badrooms in your property?'
	) );
	$property_metabox->add_field( array(
		'name'             => 'Bathrooms',
		'id'               => 'bathrooms',
		'type'             => 'text_small',
		'description'      => 'How many Bathrooms in your property?'
	) );
	$property_metabox->add_field( array(
		'name'             => 'Garages',
		'id'               => 'garages',
		'type'             => 'text_small',
		'description'      => 'How many garages in your property?'
	) );
    $aditional_details = new_cmb2_box( array(
		'id'            => 'aditional_details',
		'title'         => __( 'Aditional Details Metabox', 'timermaster' ),
		'object_types'  => 'properties', // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, 
	) );
	
    // Regular text field
	$aditional_details->add_field( array(
		'name'             => 'Water Front',
		'id'               => 'water_front',
		'type'             => 'radio',
		'options'          => array(
			'Yes' => __( 'Yes', 'garo-estate' ),
			'No'   => __( 'No', 'garo-estate' ),
		),
		'description' => 'Have you any swiming pool?'
	) );
	// Regular text field
	$aditional_details->add_field( array(
		'name'             => 'Built in date',
		'id'               => 'builtInDate',
		'type'             => 'text_date',
		'format'           => 'Y M d',
		'description'      => 'Select your house built in Year or Date'
	) );
	$aditional_details->add_field( array(
		'name'             => 'Parking Space',
		'id'               => 'parking-space',
		'type'             => 'text',
		'description'           => 'Set your parkhing space short description',
		'default'          => '2 Or More Spaces,Covered Parking,Valet Parking'
	) );
	$aditional_details->add_field( array(
		'name'             => 'View',
		'id'               => 'view',
		'type'             => 'text',
		'description'           => 'How looks like your property(short description)?',
		'default'          => 'Intracoastal View,Direct ew'
		
	) );
	$aditional_details->add_field( array(
		'name'             => 'Water Front Short Description',
		'id'               => 'wFront',
		'type'             => 'text',
		'description'           => 'Water Front short description',
		'default'           => 'Intracoastal Front,Ocean Access'
	) );
	$aditional_details->add_field( array(
		'name'             => 'Feature Options',
		'id'               => 'feature',
		'type'             => 'text',
		'repeatable'	   => true,
		'description'           => 'Add your property facilities'
	) );
	$aditional_details->add_field( array(
		'name'             => 'Property Video',
		'id'               => 'property_video',
		'type'             => 'oEmbed',
		'description'           => 'Input your property video link',
		'default'          => 'https://www.youtube.com/watch?v=2l1cK22EJBs'
	) );
	
	$client_review_metabox = new_cmb2_box( array(
		'id'            => 'client_review_metabox',
		'title'         => __( 'Client Review Metabox', 'timermaster' ),
		'object_types'  => 'client_review', // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, 
	) );
	
    // Regular text field
	$client_review_metabox->add_field( array(
		'name'             => 'Client Post Position',
		'id'               => 'post_position',
		'type'             => 'text',
		'description' => 'Input your client post position',
		'default'  => 'Web Designer'
	) );
}
add_action( 'cmb2_admin_init', 'custom_fields' );