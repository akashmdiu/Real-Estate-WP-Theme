<?php

    /**
     * ReduxFramework Barebones Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "garo-estate";

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Theme Options', 'garo-estate' ),
        'page_title'           => __( 'Theme Options', 'garo-estate' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => true,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => true,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '_options',
        // Page slug used to denote the panel
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        //'compiler'             => true,

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    // ADMIN BAR LINKS -> Setup custom links in the admin bar menu as external items.
    $args['admin_bar_links'][] = array(
        'id'    => 'redux-docs',
        'href'  => 'http://docs.reduxframework.com/',
        'title' => __( 'Documentation', 'garo-estate' ),
    );

    $args['admin_bar_links'][] = array(
        //'id'    => 'redux-support',
        'href'  => 'https://github.com/ReduxFramework/redux-framework/issues',
        'title' => __( 'Support', 'garo-estate' ),
    );

    $args['admin_bar_links'][] = array(
        'id'    => 'redux-extensions',
        'href'  => 'reduxframework.com/extensions',
        'title' => __( 'Extensions', 'garo-estate' ),
    );

    // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.
    $args['share_icons'][] = array(
        'url'   => 'https://github.com/ReduxFramework/ReduxFramework',
        'title' => 'Visit us on GitHub',
        'icon'  => 'el el-github'
        //'img'   => '', // You can use icon OR img. IMG needs to be a full URL.
    );
    $args['share_icons'][] = array(
        'url'   => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
        'title' => 'Like us on Facebook',
        'icon'  => 'el el-facebook'
    );
    $args['share_icons'][] = array(
        'url'   => 'http://twitter.com/reduxframework',
        'title' => 'Follow us on Twitter',
        'icon'  => 'el el-twitter'
    );
    $args['share_icons'][] = array(
        'url'   => 'http://www.linkedin.com/company/redux-framework',
        'title' => 'Find us on LinkedIn',
        'icon'  => 'el el-linkedin'
    );

    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( __( '<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'garo-estate' ), $v );
    } else {
        $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'garo-estate' );
    }

    // Add content after the form.
    $args['footer_text'] = __( '<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'garo-estate' );

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */

    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'garo-estate' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'garo-estate' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'garo-estate' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'garo-estate' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'garo-estate' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */

    // -> START Basic Fields

    Redux::setSection( $opt_name, array(
        'title' => __( 'Front Page', 'garo-estate' ),
        'id'    => 'front-page',
        'desc'  => __( 'Front page theme options', 'garo-estate' ),
        'icon'  => 'el el-home'
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Header Top', 'garo-estate' ),
        'desc'       => __( 'Header top area theme options ', 'garo-estate' ),
        'id'         => 'header-top',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'top_bar',
                'type'     => 'switch',
                'title'    => __( 'Top Bar ', 'garo-estate' ),
                'desc'     => __( 'On/Off your top bar section', 'garo-estate' ),
                'default'  => true
            ),
            array(
                'id'       => 'top-left',
                'type'     => 'slides',
                'title'    => __( 'Contact Info', 'garo-estate' ),
                'desc'     => __( 'Input your contact info here(ex:phone,email)', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Contact icon',
                    'description' => 'Contact info',
                    'url' => 'No need to input here'
                )
            ),
            array(
                'id'       => 'top-right',
                'type'     => 'slides',
                'title'    => __( 'Social Icon', 'garo-estate' ),
                'desc'     => __( 'Add your social account', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Icon name(ex:facebook,twitter)',
                    'description' => 'No need to input here',
                    'url' => 'Acount url'
                )
            ),
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => __( 'Logo Section', 'garo-estate' ),
        'desc'       => __( 'Logo uploader ', 'garo-estate' ),
        'id'         => 'logo-image',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'logo',
                'type'     => 'media',
                'title'    => __( 'Upload Logo', 'garo-estate' ),
                'desc'     => __( 'Upolad your theme logo', 'garo-estate' ),
                'url' => true,
                'default' => array(
                    'url'  => get_template_directory_uri().'/assets/img/logo.png',
                )
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Banner Area', 'garo-estate' ),
        'desc'       => __( 'Banner area theme options ', 'garo-estate' ),
        'id'         => 'banner_slider',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'slider_image',
                'type'     => 'gallery',
                'title'    => __( 'Slider Image', 'garo-estate' ),
                'desc'     => __( 'Upolad your banner slider image', 'garo-estate' ),
            ),
            array(
                'id'       => 'banner_title',
                'type'     => 'text',
                'title'    => __( 'Banner Section Title', 'garo-estate' ),
                'desc'     => __( 'Input your banner sectio  title', 'garo-estate' ),
                'default'  => 'PROPERTY SEARCHING JUST GOT SO EASY'
            ),
            array(
                'id'       => 'banner_subtitle',
                'type'     => 'textarea',
                'title'    => __( 'Banner Section subTitle', 'garo-estate' ),
                'desc'     => __( 'Input your banner sectio  subtitle', 'garo-estate' ),
                'default'  => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eligendi deserunt deleniti, ullam commodi sit ipsam laboriosam velit adipisci quibusdam aliquam teneturo!'
            ),
            
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Property Section', 'garo-estate' ),
        'desc'       => __( 'Submited property section theme option', 'garo-estate' ),
        'id'         => 'property_section',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'property_title',
                'type'     => 'text',
                'title'    => __( 'Section Titile', 'garo-estate' ),
                'desc'     => __( 'Input your property section title', 'garo-estate' ),
                'default' => 'TOP SUBMITTED PROPERTY',
            ),
            array(
                'id'       => 'property_subtitle',
                'type'     => 'textarea',
                'title'    => __( 'Section subTitile', 'garo-estate' ),
                'desc'     => __( 'Input your property section subtitle', 'garo-estate' ),
                'default' => 'Nulla quis dapibus nisl. Suspendisse ultricies commodo arcu nec pretium. Nullam sed arcu ultricies .',
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Welcome Section', 'garo-estate' ),
        'desc'       => __( 'Welcome section theme option', 'garo-estate' ),
        'id'         => 'welcome_section',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'wecome_bg',
                'type'     => 'media',
                'title'    => __( 'Welcome Section BG', 'garo-estate' ),
                'desc'     => __( 'Input your section bg image', 'garo-estate' ),
                'url'      => true,
                'default' => array(
                    'url' => get_template_directory_uri().'/assets/img/welcome-bg.png',
                ),
            ),
            array(
                'id'       => 'welcome_section_title',
                'type'     => 'text',
                'title'    => __( 'Logo Name', 'garo-estate' ),
                'desc'     => __( 'Input your Logo name', 'garo-estate' ),
                'default' => 'GARO ESTATE',
            ),
            array(
                'id'       => 'welcomm_support',
                'type'     => 'slides',
                'title'    => __( 'Item', 'garo-estate' ),
                'desc'     => __( 'Input your welcome itmm(max:4 item)', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Icon name(ex:help2,home)',
                    'description' => 'No need to input here',
                    'url' => 'Item title'
                ),
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Review Section', 'garo-estate' ),
        'desc'       => __( 'Review section theme option', 'garo-estate' ),
        'id'         => 'review_section',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'review_title',
                'type'     => 'text',
                'title'    => __( 'Review Section Titile', 'garo-estate' ),
                'desc'     => __( 'Input your review section title', 'garo-estate' ),
                'default' => 'OUR CUSTOMERS SAID',
            ),
        )
    ) );
   
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Check or Sell Property', 'garo-estate' ),
        'desc'       => __( 'Check or sell property section theme option', 'garo-estate' ),
        'id'         => 'check_or_asell',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'check_title',
                'type'     => 'text',
                'title'    => __( 'Check Titile', 'garo-estate' ),
                'desc'     => __( 'Input your check property title', 'garo-estate' ),
                'default' => 'ARE YOU LOOKING FOR A PROPERTY?',
            ),
            array(
                'id'       => 'check_desc',
                'type'     => 'textarea',
                'title'    => __( 'Check Short Description', 'garo-estate' ),
                'desc'     => __( 'Input your check property short description', 'garo-estate' ),
                'default' => 'varius od lio eget conseq uat blandit, lorem auglue comm lodo nisl no us nibh mas lsa.',
            ),
            array(
                'id'       => 'sell_title',
                'type'     => 'text',
                'title'    => __( 'Sell Titile', 'garo-estate' ),
                'desc'     => __( 'Input your Sell property button title', 'garo-estate' ),
                'default' => 'DO YOU WANT TO SELL A PROPERTY?',
            ),
            array(
                'id'       => 'sell_desc',
                'type'     => 'textarea',
                'title'    => __( 'Sell Short Description', 'garo-estate' ),
                'desc'     => __( 'Input your Sell property button short description', 'garo-estate' ),
                'default' => 'varius od lio eget conseq uat blandit, lorem auglue comm lodo nisl no us nibh mas lsa.',
            ),
            array(
                'id'       => 'contact_number',
                'type'     => 'text',
                'title'    => __( 'Contact Number', 'garo-estate' ),
                'desc'     => __( 'Input your contact number', 'garo-estate' ),
                'default' => '+ 3-123- 424-5700',
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title' => __( 'Footer', 'garo-estate' ),
        'id'    => 'footer',
        'desc'  => __( 'Footer section', 'garo-estate' ),
        'icon'  => 'el el-hand-down'
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer One Widget Options', 'garo-estate' ),
        'desc'       => __( 'Footer area widget theme options ', 'garo-estate' ),
        'id'         => 'footer-one-widget',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'title_one',
                'type'     => 'text',
                'title'    => __( 'Footer One Title', 'garo-estate' ),
                'desc'     => __( 'Input your footer one title', 'garo-estate' ),
                'default'  => "About Us"
            ),
            array(
                'id'       => 'footer_one',
                'type'     => 'editor',
                'title'    => __( 'Footer One Widget', 'garo-estate' ),
                'desc'     => __( 'Input your about us info', 'garo-estate' ),
                'default'  => "Lorem ipsum dolor sit amet, consectetuer adipiscin g elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam."
            ),
            array(
                'id'       => 'image_icon',
                'type'     => 'slides',
                'title'    => __( 'Image Icon', 'garo-estate' ),
                'desc'     => __( 'Upload your Image Icon', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'No need to input here',
                    'description' => 'No need to input here',
                    'url' => 'Link'
                )
            ),
            
           
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Two Widget Options', 'garo-estate' ),
        'desc'       => __( 'Footer area widget theme options ', 'garo-estate' ),
        'id'         => 'footer-two-widget',
        'subsection' => true,
        'fields'     => array(   
            array(
                'id'       => 'title_two',
                'type'     => 'text',
                'title'    => __( 'Footer Two Title', 'garo-estate' ),
                'desc'     => __( 'Input your footer two title', 'garo-estate' ),
                'default'  => "Contact Us"
            ),             
            array(
                'id'       => 'footer_two',
                'type'     => 'editor',
                'title'    => __( 'Footer Two Widget', 'garo-estate' ),
                'desc'     => __( 'Input your contact us info', 'garo-estate' ),
                'default'  => "Ohio Real Estate Guys
                    93 W Franklin St #106              
                    Centerville, Ohio 45459              
                    (937) 490-9743              
                    fa fa-envelope-o info@OhioRealEstateGuys.Com"
                ),
            )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Three Widget Options', 'garo-estate' ),
        'desc'       => __( 'Footer area widget theme options ', 'garo-estate' ),
        'id'         => 'footer-three-widget',
        'subsection' => true,
        'fields'     => array(  
            array(
                'id'       => 'title_three',
                'type'     => 'text',
                'title'    => __( 'Footer three Title', 'garo-estate' ),
                'desc'     => __( 'Input your footer three title', 'garo-estate' ),
                'default'  => "Usefull Links"
            ),              
            array(
                'id'       => 'footer_three',
                'type'     => 'slides',
                'title'    => __( 'Footer Three Widget', 'garo-estate' ),
                'desc'     => __( 'Add your other usefull links', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Page name',
                    'description' => 'No need to input here',
                    'url' => 'Page url'
                )
            ),
            array(
                'id'       => 'social_link',
                'type'     => 'slides',
                'title'    => __( 'Social Link', 'garo-estate' ),
                'desc'     => __( 'Add your social links', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Tcon name(ex:facebook,twitter)',
                    'description' => 'No need to input here',
                    'url' => 'Link url'
                )
            ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Four Widget Options', 'garo-estate' ),
        'desc'       => __( 'Footer area widget theme options ', 'garo-estate' ),
        'id'         => 'footer-four-widget',
        'subsection' => true,
        'fields'     => array(                
            array(
                'id'       => 'title_four',
                'type'     => 'text',
                'title'    => __( 'Footer Four Title', 'garo-estate' ),
                'desc'     => __( 'Input your footer four title', 'garo-estate' ),
                'default'  => "Real Estate For Sale"
            ),
            array(
                'id'       => 'footer_four',
                'type'     => 'slides',
                'title'    => __( 'Footer Four Widget', 'garo-estate' ),
                'desc'     => __( 'Add your REAL ESTATE FOR SALE links', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Page name',
                    'description' => 'No need to input here',
                    'url' => 'Page url'
                )
            ),
        )
    ) );
    
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Options', 'garo-estate' ),
        'desc'       => __( 'Footer theme options ', 'garo-estate' ),
        'id'         => 'footer_section',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'footer_bg',
                'type'     => 'media',
                'title'    => __( 'Footer BG', 'garo-estate' ),
                'desc'     => __( 'Upload your footer BG image', 'garo-estate' ),
                'url'      => true,
                'default'  => array(
                    'url'  => get_template_directory_uri().'/assets/img/bg-footer.jpg',
                )
            ),
            array(
                'id'       => 'copyright',
                'type'     => 'editor',
                'title'    => __( 'Copyright Text', 'garo-estate' ),
                'desc'     => __( 'Input your copyright text', 'garo-estate' ),
                'default'  => '© Copyright 2018 Ohio RealState All Right Rererved'
            ),
            array(             
                'id'       => 'other_page',
                'type'     => 'slides',
                'title'    => __( 'Other page', 'garo-estate' ),
                'desc'     => __( 'Add your page item', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Page name',
                    'description' => 'No need to input here',
                    'url' => 'Page url'
                )
            )
        )
    ) );
    
    Redux::setSection( $opt_name, array(
        'title' => __( 'Agent Profile', 'garo-estate' ),
        'id'    => 'agent_profile',
        'desc'  => __( 'Setup your agent profile', 'garo-estate' ),
        'icon'  => 'el el-user'
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Agent Profile  Options', 'garo-estate' ),
        'desc'       => __( 'Agent profile theme options ', 'garo-estate' ),
        'id'         => 'agent_profile_options',
        'subsection' => true,
        'fields'     => array(                
            array(
                'id'       => 'agent_photo',
                'type'     => 'media',
                'title'    => __( 'Agent Profile Photo', 'garo-estate' ),
                'desc'     => __( 'Upload your agent profile photo', 'garo-estate' ),
                'url'      => true,
                'default'  => array(
                    'url' => get_template_directory_uri().'/assets/img/client-face1.png',
                )
            ),
            array(
                'id'       => 'agent_name',
                'type'     => 'text',
                'title'    => __( 'Agent Name', 'garo-estate' ),
                'desc'     => __( 'Input your agent name', 'garo-estate' ),
                'default'  => 'NATHAN JAMES'
            ),
            array(
                'id'       => 'subtitle',
                'type'     => 'text',
                'title'    => __( 'Agent Subtitle', 'garo-estate' ),
                'desc'     => __( 'Input your subtitle', 'garo-estate' ),
                'default'  => 'Real Estate Agent'
            ),
            array(
                'id'       => 'agent_social_account',
                'type'     => 'slides',
                'title'    => __( 'Social Accouns', 'garo-estate' ),
                'desc'     => __( 'Setup your agent socail account', 'garo-estate' ),
                'placeholder' => array(
                    'title' => 'Icon name(ex:facebook,twitter)',
                    'description' => 'No need to input here',
                    'url' => 'Account url'
                )
            ),
            array(
                'id'       => 'agent_contact',
                'type'     => 'editor',
                'title'    => __( 'Agent Contact Info and Description', 'garo-estate' ),
                'desc'     => __( 'Input your agent contact info and description ', 'garo-estate' ),
                'default'  => '<ul class="dealer-contacts">                                       
                <li><i class="pe-7s-map-marker strong"> </i> 9089 your adress her</li>
                <li><i class="pe-7s-mail strong"> </i> email@yourcompany.com</li>
                <li><i class="pe-7s-call strong"> </i> +1 908 967 5906</li>
            </ul>
            <p>Duis mollis  blandit tempus porttitor curabiturDuis mollis  blandit tempus porttitor curabitur , est non…</p>'
            ),
        )
    ) );

    /*
     * <--- END SECTIONS
     */
