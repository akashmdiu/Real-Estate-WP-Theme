<?php
    register_post_type('properties', array(
    'labels' => array(
        'menu_name' => 'Your Properties',
        'name' => 'Property',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Item',
        'all_items' => 'All Properties'
    ),
    'public' => true,
    'supports' => array(
        'title', 'editor','thumbnail','revisions','comment'
    ),
    'menu_icon' => 'dashicons-admin-home',
    ));
    register_post_type('client_review', array(
        'labels' => array(
            'menu_name' => 'Client Reviews',
            'name' => 'Client Review',
            'add_new' => 'Add New',
            'add_new_item' => 'Add New Item',
            'all_items' => 'All Reviews'
        ),
        'public' => true,
        'supports' => array(
            'title', 'editor','thumbnail','revisions',
        ),
        'menu_icon' => 'dashicons-heart',
    ));
    register_taxonomy('Property_location','properties', array(
        'labels' => array(    
        'name' => 'property Location',
        'add_new_item' => 'Add New Location',
        ),
        'public' => true,
        'show_admin_column' => true,
         'hierarchical' => true
    ));
    register_taxonomy('recommended','properties', array(
        'labels' => array(    
        'name' => 'Recommended Property',
        ),
        'public' => true,
        'show_admin_column' => true,
         'hierarchical' => true
    ));
