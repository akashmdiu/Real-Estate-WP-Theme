<?php
namespace WPAS\Enum;

class RequestMethod extends BasicEnum {
    const POST = 'POST';
    const GET = 'GET';
}
