<?php
namespace WPAS\Parser;

interface InputArgParser  {
    public static function parse(array $args);
}