:heavy_exclamation_mark: UPDATE (6/15/2017): _This repository is no longer maintained_. Feel free to fork and modify as you wish.

# WP Advanced Search
#### A PHP framework for building advanced search forms in WordPress

[View Documentation](http://wpadvancedsearch.com/docs/setup)

**Technical Requirements:** PHP version 5.3 or higher, WordPress version 4.1 or higher

[![Code Climate](https://codeclimate.com/github/raideus/wp-advanced-search/badges/gpa.svg)](https://codeclimate.com/github/raideus/wp-advanced-search)
