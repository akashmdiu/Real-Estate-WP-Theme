<?php
function my_form(){
	//front page search form
	$args = array();
	$args['wp_query'] = array(
							'post_type' => array('properties', 'gs_field', 'gs_param'),
							'posts_per_page' => 4,
							'order' => 'ASC'
							);
							
	$args['form'] = array( 'action' => get_bloginfo('url') . '/search' );
	$args['fields'][] = array(
		'type' => 'html',
		'value' => '<button type="button" class="btn toggle-btn search-btn"><i class="fa fa-bars"></i></button>'
);
	$args['fields'][] = array(
							'type' => 'search',
							'placeholder' => 'Keyword',
							'class' => 'form-control field-height'
							);
	
	$args['fields'][] = array(
							'type' => 'meta_key',
							'meta_key' => 'property_location',
							'class' => 'form-control field-height',
							'format' => 'select',
							'values' => array(							
								'' => '-Property Location-',
									'dhaka'  => 'Dhaka',
									'barisal' => 'Barisal',
									'chittagong'  => 'Chittagong',
									'khulna' => 'Khulna',
									'sylhet'  => 'Sylhet',
									'mymensingh	' => 'Mymensingh',
									'rajshahi'  => 'Rajshahi',
									'rangpur' => 'Rangpur',
									'comilla'  => 'Comilla',
									'narayanganj' => 'Narayanganj',
									'gazipur'  => 'Gazipur',
								)
							);
	$args['fields'][] = array(
							'type' => 'meta_key',
							'format' => 'select',
							'meta_key' => 'property_type',
							'values' => array(
								'' => '-Property Type-',
								'apartment' => 'Apartments',
								'flat' => 'Flats',
								'rent' => 'Rents'
							),
							'class' => 'form-control field-height'
	);
	$args['fields'][] = array(
							'type' => 'html',
							'value' => '<button type="submit" class="search-btn btn"><i class="fa fa-search"></i></button>',
						);
	register_wpas_form('myform', $args);

	//sidebar search form
	$form_args[] = array();
	$form_args['wp_query'] = array(
		'post_type' => 'properties',
		'posts_per_page' => '5',

	);
	$form_args['form'] = array( 'action' => get_bloginfo('url') . '/search' );
	$form_args['fields'][] = array(
		'type' => 'search',
		'class' => 'form-control field-height',
		'placeholder' => 'Kew Word'
	);
	$form_args['fields'][] = array(
		'type' => 'meta_key',
		'format' => 'select',
		'meta_key' => 'property_type',
		'class' => 'form-control',
		'values' => array(
			'' => 'All',
			'flat' => 'Flats',
			'apartment' => 'Apartments',
			'rent' => 'Rents'
		),
		'label' => 'Property Type'
	);
	$form_args['fields'][] = array(
		'type' => 'meta_key',
		'format' => 'select',
		'meta_key' => 'badrooms',
		'class' => 'form-control',
		'values' => array(
			'' => 'All',
			'1' => '1',
			'2' => '2',
			'3' => '3',
			'4' => '4',
			'5' => '5',
			'6' => '6',
			'7' => '7',
			'8' => '8',
			'9' => '9',
			'10' => '10',
		),
		'label' => 'Bedrooms'
	);
	$form_args['fields'][] = array(
		'type' => 'meta_key',
		'format' => 'select',
		'meta_key' => 'bathrooms',
		'class' => 'form-control',
		'values' => array(
			'' => 'All',
			'1' => '1',
			'2' => '2',
			'3' => '3',
			'4' => '4',
			'5' => '5',
			'6' => '6',
			'7' => '7',
			'8' => '8',
			'9' => '9',
			'10' => '10',
		),
		'label' => 'Bathrooms'
	);
	$form_args['fields'][] = array(
		'type' => 'meta_key',
		'format' => 'select',
		'meta_key' => 'property_location',
		'class' => 'form-control',
		'values' => array(
			'' => 'All',
			'dhaka'  => 'Dhaka',
			'barisal' => 'Barisal',
			'chittagong'  => 'Chittagong',
			'khulna' => 'Khulna',
			'sylhet'  => 'Sylhet',
			'mymensingh	' => 'Mymensingh',
			'rajshahi'  => 'Rajshahi',
			'rangpur' => 'Rangpur',
			'comilla'  => 'Comilla',
			'narayanganj' => 'Narayanganj',
			'gazipur'  => 'Gazipur',
		),
		'label' => 'Property Location'
	);
	
	$form_args['fields'][] = array(
		'type' => 'meta_key',
		'inputs' => array(
			array(
				'format' => 'number',
				'value' => '0',
				'label' => 'Min Price($)'
			),
			array(
				'format' => 'number',
				'value' => '500000',
				'label' => 'Max Price($)'
			),
		),
		'meta_key' => 'sell_price',
		'class' => 'form-control field-height',
		'compare' => 'BETWEEN',
		'data_type' => 'NUMERIC',
);
	$form_args['fields'][] = array(
		'type' => 'submit',
		'class' => 'btn btn-primary field-height',
		'value' => 'Search...'
	);
	register_wpas_form('anotherform', $form_args);

}
add_action('init', 'my_form');

// function front_page_searh(){
// 	$args = array();
// 	$args['wp_query'] = array(
// 							'post_type' => array('properties', 'gs_field', 'gs_param'),
// 							'posts_per_page' => 10,
// 							'order' => 'ASC'
// 							);
// 	$args['fields'][] = array(
// 							'type' => 'search',
// 							'placeholder' => 'Keyword',
// 							'class' => 'form-control'
// 							);
// 	$args['fields'][] = array(
// 							'type' => 'meta_key',
// 							'meta_key' => 'property_location',
// 							'class' => 'form-control',
// 							'format' => 'select',
// 							'values' => array(
// 									'' => 'All',
// 									'dhaka'  => 'Dhaka',
// 									'barisal' => 'Barisal',
// 									'chittagong'  => 'Chittagong',
// 									'khulna' => 'Khulna',
// 									'sylhet'  => 'Sylhet',
// 									'mymensingh	' => 'Mymensingh',
// 									'rajshahi'  => 'Rajshahi',
// 									'rangpur' => 'Rangpur',
// 									'comilla'  => 'Comilla',
// 									'narayanganj' => 'Narayanganj',
// 									'gazipur'  => 'Gazipur',
// 								)
// 							);
// 	$args['fields'][] = array(
// 							'type' => 'html',
// 							'value' => '<button type="submit" class="btn"><i class="fa fa-search"></i></button>'
// 						);
// 	register_wpas_form('front_page_form_search', $args);
						
						
// }
// add_action('init', 'front_page_search');