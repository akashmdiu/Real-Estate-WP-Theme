<?php
    register_sidebar(array(
        'name' => 'Footer One',
        'id' => 'footer_1',
        'before_title' => '<h4>',
        'after_title' => '</h4>
        <div class="footer-title-line"></div>',
        'before_widget' => '<div class="single-footer">',
        'after_widget' => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Footer Two',
        'id' => 'footer_2',
        'before_title' => '<h4>',
        'after_title' => '</h4>
        <div class="footer-title-line"></div>',
        'before_widget' => '<div class="single-footer">',
        'after_widget' => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Footer three',
        'id' => 'footer_3',
        'before_title' => '<h4>',
        'after_title' => '</h4>
        <div class="footer-title-line"></div>',
        'before_widget' => '<div class="single-footer">',
        'after_widget' => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Footer four',
        'id' => 'footer_4',
        'before_title' => '<h4>',
        'after_title' => '</h4>
        <div class="footer-title-line"></div>',
        'before_widget' => '<div class="single-footer">',
        'after_widget' => '</div>'
    ));
    register_sidebar(array(
        'name' => 'Siderbar Widget',
        'id' => 'sidebar',
        'before_title' => '<div class="panel-heading">
        <h3 class="panel-title">',
        'after_title' => '</h3>
        </div>',
        'before_widget' => '<div class="panel panel-default sidebar-menu wow fadeInRight animated" >',
        'after_widget' => '</div>'
    ));
    
?>